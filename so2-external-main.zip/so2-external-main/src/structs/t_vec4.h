#pragma once

struct vec4_t {
	float x, y, z, w;
};
