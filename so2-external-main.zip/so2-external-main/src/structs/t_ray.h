#pragma once
#include "t_vec3.h"

struct ray_t {
	vec3_t m_Origin{};
	vec3_t m_Direction{};
};
